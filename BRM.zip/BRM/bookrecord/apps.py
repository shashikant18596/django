from django.apps import AppConfig


class BookrecordConfig(AppConfig):
    name = 'bookrecord'
