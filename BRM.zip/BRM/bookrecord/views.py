from django.contrib import auth
from django.contrib.auth.models import User

from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect

from . import models
from .forms import searchform, newbookform


def viewbook(request):
    books = models.Book.objects.all()
    res = render(request, "viewbook.html", {'books': books})
    return res


def home(request):
    return render(request, 'home.html')


def newbook(request):
    form = newbookform()
    res = render(request, 'newbook.html', {'form': form})
    return res


def add(request):
    if request.method == "POST":
        form = newbookform(request.POST)
        book = models.Book()
        book.title = form.data['title']
        book.price = form.data['price']
        book.author = form.data['author']
        book.publisher = form.data['publisher']
        book.save()
    s = "Record Stored<br><a href ='/viewbook'>view all Books</a>"
    return HttpResponse(s)


def editbook(request):
    book = models.Book.objects.get(id=request.GET['bookid'])
    fields = {'title': book.title, 'price': book.price, 'author': book.author, 'publisher': book.publisher}
    form = newbookform(initial=fields)
    res = render(request, 'editbook.html', {'book': book, 'form': form})
    return res


def edit(request):
    if request.method == 'POST':
        form = newbookform(request.POST)
        book = models.Book()
        book.id = request.POST['bookid']
        book.title = form.data['title']
        book.price = form.data['price']
        book.author = form.data['author']
        book.publisher = form.data['publisher']
        book.save()
    return HttpResponseRedirect('/viewbook')


def deletebook(request):
    bookid = request.GET['bookid']
    book = models.Book.objects.filter(id=bookid)
    book.delete()
    return HttpResponseRedirect('/viewbook')


def searchbook(request):
    form = searchform()
    res = render(request, 'searchbook.html', {'form': form})
    return res


def search(request):
    form = searchform(request.POST)
    books = models.Book.objects.filter(title=form.data['title'])
    res = render(request, 'searchbook.html', {'form': form, 'books': books})
    return res


def userlogin(request):
    if request.method == 'POST':
        username1 = request.POST['username']
        password1 = request.POST['password']
        x = auth.authenticate(request, username=username1, password=password1)
        if x is None:
            return redirect('/login')
        else:
            return redirect('/viewbook')
    else:
        return render(request, 'login.html')


def signup(request):
    if request.method == "POST":
        user_name = request.POST['UserName']
        first_name = request.POST['First Name']
        last_name = request.POST['Last Name']
        email = request.POST['Email']
        password = request.POST['Password']
        x = User.objects.create_user(UserName=user_name, First_Name=first_name, Last_name=last_name, Email=email,
                                     Password=password)
        x.save()
        print('user created')
        return redirect('viewbook')
    return render(request, 'signup.html')
